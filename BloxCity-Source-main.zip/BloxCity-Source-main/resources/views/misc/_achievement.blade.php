<div class="cell medium-6">
    <div class="container achievement-container mb-25">
        <img class="achievement-image" src="{{ $achievement['image'] }}">
        <div class="achievement-content">
            <div class="achievement-name">{{ $achievement['name'] }}</div>
            <div class="achievement-description" style="white-space: pre-line">{{ $achievement['description'] }}</div>
        </div>
    </div>
</div>