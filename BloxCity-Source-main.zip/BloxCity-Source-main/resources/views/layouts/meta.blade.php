<meta name="author" content="BLOX City">
<meta name="description" content="{{ $pageDescription ?? 'BLOX City is the fastest growing user-generated sandbox platform designed for people of all ages. Get started today, and let your creativity flow.' }}">
<meta name="keywords" content="BLOX City, roblox alternative, building game, free online games, user generated content, user generated sandbox, free games, online games, old roblox, roblox free, classic roblox">

<meta property="og:site_name" content="BLOX City">
<meta property="og:type" content="website">
<meta property="og:title" content="{{ $title ?? 'BLOX City' }}">
<meta property="og:description" content="{{ $pageDescription ?? 'BLOX City is the fastest growing user-generated sandbox platform designed for people of all ages. Get started today, and let your creativity flow.' }}">
<meta property="og:image" content="{{ $pageImage ?? asset('img/branding/favicon.png') }}">