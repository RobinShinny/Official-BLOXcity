<x-app-layout>
    <x-slot name="title">Feature Disabled</x-slot>
    <x-slot name="navigation"></x-slot>
    <div class="container construction-container">
        <i class="icon icon-sad construction-icon"></i>
        <div class="construction-text">Sorry, that feature is disabled right now for maintenance. Please try again later.</div>
    </div>
</x-app-layout>