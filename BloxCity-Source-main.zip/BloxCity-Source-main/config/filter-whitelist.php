<?php

return [
    'words' => []
];