<?php

return [
    'words' => [
        'kekema',
        'kekma',
        'nigger',
        'nigga',
        'fag',
        'faggot',
        'tranny',
        'porn',
        'phub',
        'pornhub',
        'bitly',
        'bit.ly',
        'pizza',
		'fuck',
		'cunt',
		'vagina',
		'pussy',
		'fuckoff',
		'fock',
		'retard',
		'cancer',
		'blackcunt',
		'brickplanet',
		'brickhill',
		'pornhub.com',
    ]
];