<?php

return [

    'tables' => [
        'fr_pivot' => 'friendships',
    ],
];
