<?php

namespace App\Models\Membership;

use Illuminate\Database\Eloquent\Model;

class MembershipValue extends Model
{
    //
}
