<?php

namespace App\Http\Controllers\AIS;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Carbon\Carbon;
use App\Models\AntelopeLog;

class InfoController extends Controller
{
    
}
